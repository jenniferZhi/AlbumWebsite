# Do NOT commit this file to github
# Make a seperate one for your deployed environment

env = dict(
	host = '0.0.0.0',
	port = 4450,
	user = 'group19', 
	password = 'stayhungry',
	db = 'group19db', 
)
